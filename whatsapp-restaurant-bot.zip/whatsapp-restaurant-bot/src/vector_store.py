import os
import json
import google.generativeai as genai
from pinecone import Pinecone, ServerlessSpec
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings

from src.config import GEMINI_API_KEY, PINECONE_API_KEY, PINECONE_INDEX_NAME, PINECONE_DIMENSION, PINECONE_METRIC

# Initialize Gemini
genai.configure(api_key=GEMINI_API_KEY)

# Initialize embeddings model
embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=GEMINI_API_KEY)

# Initialize Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY)

# Create or get index
def init_pinecone():
    """Initialize Pinecone index or create if it doesn't exist"""
    try:
        # Check if index exists
        indexes = pc.list_indexes()
        
        index_names = [index.name for index in indexes]
        
        if PINECONE_INDEX_NAME not in index_names:
            # Create index if it doesn't exist
            pc.create_index(
                name=PINECONE_INDEX_NAME,
                dimension=PINECONE_DIMENSION,
                metric=PINECONE_METRIC,
                spec=ServerlessSpec(
                    cloud="aws",
                    region="us-east-1"
                )
            )
            print(f"Created new Pinecone index: {PINECONE_INDEX_NAME}")
        
        # Get index
        index = pc.Index(PINECONE_INDEX_NAME)
        return index
    except Exception as e:
        print(f"Error initializing Pinecone: {e}")
        raise

# Text splitter for chunking menu items
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=100,
    separators=["\n\n", "\n", ".", " ", ""]
)

# Generate embeddings for text
def generate_embedding(text):
    """Generate embedding for a piece of text"""
    try:
        embedding = embeddings.embed_query(text)
        return embedding
    except Exception as e:
        print(f"Error generating embedding: {e}")
        raise

# Upsert data to Pinecone
def upsert_to_pinecone(index, data):
    """
    Upsert data to Pinecone
    
    Args:
        index: Pinecone index
        data: List of dictionaries with id, vector, and metadata
    """
    try:
        index.upsert(vectors=data)
        print(f"Upserted {len(data)} vectors to Pinecone")
    except Exception as e:
        print(f"Error upserting to Pinecone: {e}")
        raise

# Query Pinecone
def query_pinecone(index, query_embedding, top_k=5):
    """
    Query Pinecone for similar vectors
    
    Args:
        index: Pinecone index
        query_embedding: Query embedding vector
        top_k: Number of results to return
        
    Returns:
        List of matches
    """
    try:
        results = index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True
        )
        return results
    except Exception as e:
        print(f"Error querying Pinecone: {e}")
        raise
