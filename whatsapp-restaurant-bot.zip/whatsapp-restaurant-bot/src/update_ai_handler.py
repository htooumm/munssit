import os
import sys

# Add the project root to the Python path
sys.path.append('/home/ubuntu/whatsapp-restaurant-bot')

from src.rag_implementation import GeminiRAG
from src.vector_store import init_pinecone

def update_ai_handler():
    """
    Update the AI handler to use the RAG implementation
    """
    try:
        # Initialize Pinecone
        pinecone_index = init_pinecone()
        
        # Initialize RAG
        rag = GeminiRAG(pinecone_index)
        
        # Test the RAG implementation
        test_queries = [
            "ما هي أنواع الفطور المتوفرة لديكم؟",
            "كم سعر صحن الشكشوكة؟",
            "هل لديكم شاورما دجاج؟",
            "ما هي أفضل السلطات عندكم؟"
        ]
        
        print("Testing RAG implementation with sample queries:")
        for query in test_queries:
            print(f"\nQuery: {query}")
            response = rag.generate_response(query)
            print(f"Response: {response}")
        
        print("\nRAG implementation successfully tested!")
        return True
    except Exception as e:
        print(f"Error updating AI handler: {e}")
        return False

if __name__ == "__main__":
    update_ai_handler()
