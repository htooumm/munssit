import os
import json
import re

def clean_menu_text(text):
    """
    Clean and normalize the OCR-extracted menu text
    
    Args:
        text: Raw OCR text
        
    Returns:
        Cleaned text
    """
    # Remove page markers
    text = re.sub(r'---\s*PAGE\s*\d+\s*---', '', text)
    
    # Remove excessive whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Remove non-Arabic, non-numeric, and non-basic punctuation characters
    # but keep Arabic, numbers, and basic punctuation
    text = re.sub(r'[^\u0600-\u06FF\s\d\.,-]', '', text)
    
    return text

def extract_menu_items(text):
    """
    Extract menu items from cleaned text
    
    Args:
        text: Cleaned OCR text
        
    Returns:
        List of menu items with name and price
    """
    menu_items = []
    
    # Split text into lines
    lines = text.split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Try to extract item name and price
        # Pattern: Arabic text followed by numbers (price)
        match = re.search(r'([\u0600-\u06FF\s]+)\s*(\d+(?:\.\d+)?)', line)
        
        if match:
            name = match.group(1).strip()
            price = match.group(2).strip()
            
            if name and price:
                menu_items.append({
                    "name": name,
                    "price": float(price)
                })
    
    return menu_items

def categorize_menu_items(menu_items):
    """
    Attempt to categorize menu items based on keywords
    
    Args:
        menu_items: List of menu items
        
    Returns:
        Dictionary of categorized menu items
    """
    # Define categories and their keywords
    categories = {
        "فطور": ["فطور", "فول", "بيض", "شكشوكة"],
        "شاورما": ["شاورما", "لوزينا"],
        "سلطات": ["تبولة", "فتوش", "سلطة"],
        "مشروبات": ["عصير", "مشروب"],
        "وجبات": ["وجبة", "صحن", "طبق"],
        "أخرى": []  # Default category
    }
    
    categorized_menu = {category: [] for category in categories}
    
    for item in menu_items:
        item_name = item["name"].lower()
        
        # Check which category the item belongs to
        assigned = False
        for category, keywords in categories.items():
            for keyword in keywords:
                if keyword in item_name:
                    categorized_menu[category].append(item)
                    assigned = True
                    break
            if assigned:
                break
        
        # If not assigned to any category, put in "Other"
        if not assigned:
            categorized_menu["أخرى"].append(item)
    
    return categorized_menu

def structure_menu_data(ocr_file_path, output_file_path):
    """
    Process OCR-extracted menu text and structure it into JSON
    
    Args:
        ocr_file_path: Path to OCR-extracted text file
        output_file_path: Path to save structured JSON
        
    Returns:
        Structured menu data
    """
    # Read OCR text
    with open(ocr_file_path, 'r', encoding='utf-8') as f:
        ocr_text = f.read()
    
    # Clean text
    cleaned_text = clean_menu_text(ocr_text)
    
    # Extract menu items
    menu_items = extract_menu_items(cleaned_text)
    
    # Categorize menu items
    categorized_menu = categorize_menu_items(menu_items)
    
    # Create structured menu data
    menu_data = {
        "restaurant_name": "مطعم سما الشام",
        "menu": {
            "categories": []
        }
    }
    
    # Add categories to structured data
    for category, items in categorized_menu.items():
        if items:  # Only add non-empty categories
            category_data = {
                "name": category,
                "items": []
            }
            
            for item in items:
                item_data = {
                    "name": item["name"],
                    "price": item["price"],
                    "description": "",  # No descriptions available from OCR
                    "metadata": {
                        "category": category
                    }
                }
                category_data["items"].append(item_data)
            
            menu_data["menu"]["categories"].append(category_data)
    
    # Save structured data to JSON file
    with open(output_file_path, 'w', encoding='utf-8') as f:
        json.dump(menu_data, f, ensure_ascii=False, indent=2)
    
    print(f"Structured menu data saved to {output_file_path}")
    return menu_data

if __name__ == "__main__":
    ocr_file_path = '/home/ubuntu/menu_ocr.txt'
    output_file_path = '/home/ubuntu/whatsapp-restaurant-bot/data/menu_structured.json'
    
    structure_menu_data(ocr_file_path, output_file_path)
