import os
import sys
import json
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

# Add the project root to the Python path
sys.path.append('/home/ubuntu/whatsapp-restaurant-bot')

from src.config import WEBHOOK_PATH, VERIFY_TOKEN
from src.whatsapp_integration import WebhookHandler
from src.ai_handler import GeminiAI
from src.vector_store import init_pinecone

# Initialize FastAPI app
app = FastAPI(title="Restaurant WhatsApp Bot")

# Initialize Pinecone
pinecone_index = init_pinecone()

# Initialize AI handler
ai_handler = GeminiAI(pinecone_index)

# Initialize webhook handler
webhook_handler = WebhookHandler(ai_handler)

@app.get("/")
async def root():
    """Root endpoint for health check"""
    return {"status": "active", "message": "Restaurant WhatsApp Bot is running"}

@app.get(WEBHOOK_PATH)
async def verify_webhook(request: Request):
    """Verify webhook for WhatsApp API"""
    return await webhook_handler.verify_webhook(request)

@app.post(WEBHOOK_PATH)
async def process_webhook(request: Request):
    """Process webhook events from WhatsApp"""
    return await webhook_handler.process_messages(request)

def start():
    """Start the FastAPI server"""
    import uvicorn
    from src.config import APP_HOST, APP_PORT
    uvicorn.run(app, host=APP_HOST, port=APP_PORT)

if __name__ == "__main__":
    start()
