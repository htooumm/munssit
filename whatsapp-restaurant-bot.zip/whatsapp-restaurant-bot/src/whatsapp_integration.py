import os
import json
import requests
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse

from src.config import WHAPI_API_URL, WHAPI_API_TOKEN, WEBHOOK_PATH, VERIFY_TOKEN

class WhatsAppClient:
    """
    Client for interacting with the WhatsApp API
    """
    def __init__(self):
        self.api_url = WHAPI_API_URL
        self.api_token = WHAPI_API_TOKEN
        self.headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json"
        }
    
    def send_message(self, to_number, message_text):
        """
        Send a text message to a WhatsApp number
        
        Args:
            to_number: Recipient phone number
            message_text: Message text
            
        Returns:
            Response from API
        """
        try:
            payload = {
                "to": to_number,
                "type": "text",
                "text": {
                    "body": message_text
                }
            }
            
            response = requests.post(
                f"{self.api_url}/messages",
                headers=self.headers,
                json=payload
            )
            
            if response.status_code != 200:
                print(f"Error sending message: {response.text}")
                
            return response.json()
        except Exception as e:
            print(f"Error sending message: {e}")
            raise
    
    def send_image(self, to_number, image_url, caption=None):
        """
        Send an image message to a WhatsApp number
        
        Args:
            to_number: Recipient phone number
            image_url: URL of the image
            caption: Optional caption for the image
            
        Returns:
            Response from API
        """
        try:
            payload = {
                "to": to_number,
                "type": "image",
                "image": {
                    "url": image_url
                }
            }
            
            if caption:
                payload["image"]["caption"] = caption
            
            response = requests.post(
                f"{self.api_url}/messages",
                headers=self.headers,
                json=payload
            )
            
            if response.status_code != 200:
                print(f"Error sending image: {response.text}")
                
            return response.json()
        except Exception as e:
            print(f"Error sending image: {e}")
            raise
    
    def mark_message_as_read(self, message_id):
        """
        Mark a message as read
        
        Args:
            message_id: ID of the message to mark as read
            
        Returns:
            Response from API
        """
        try:
            payload = {
                "message_id": message_id
            }
            
            response = requests.post(
                f"{self.api_url}/messages/{message_id}/read",
                headers=self.headers,
                json=payload
            )
            
            if response.status_code != 200:
                print(f"Error marking message as read: {response.text}")
                
            return response.json()
        except Exception as e:
            print(f"Error marking message as read: {e}")
            raise

class WebhookHandler:
    """
    Handler for WhatsApp webhook events
    """
    def __init__(self, ai_handler):
        self.whatsapp_client = WhatsAppClient()
        self.ai_handler = ai_handler
    
    async def verify_webhook(self, request: Request):
        """
        Verify webhook for WhatsApp API
        """
        # Get query parameters
        query_params = dict(request.query_params)
        
        # Check if verification token is correct
        if query_params.get("hub.verify_token") == VERIFY_TOKEN:
            # Return challenge
            return int(query_params.get("hub.challenge", 0))
        
        # Return error if token is invalid
        raise HTTPException(status_code=403, detail="Verification token mismatch")
    
    async def process_webhook(self, request: Request):
        """
        Process webhook events from WhatsApp
        """
        try:
            # Get request body
            body = await request.json()
            
            # Process messages
            result = await self.process_messages(body)
            
            return JSONResponse(content=result)
        except Exception as e:
            print(f"Error processing webhook: {e}")
            return JSONResponse(content={"status": "error", "message": str(e)})
    
    async def process_messages(self, data):
        """
        Process incoming WhatsApp messages
        
        Args:
            data: Webhook event data
            
        Returns:
            Processing result
        """
        try:
            # Check if data contains messages
            if 'messages' not in data:
                return {"status": "error", "message": "No messages found"}
            
            for message in data['messages']:
                # Process only text messages
                if message.get('type') != 'text':
                    continue
                
                # Extract message details
                message_id = message.get('id')
                from_number = message.get('from')
                message_text = message.get('body', {}).get('text', '')
                
                # Mark message as read
                self.whatsapp_client.mark_message_as_read(message_id)
                
                # Generate AI response
                ai_response = self.ai_handler.generate_response(message_text)
                
                # Send response
                self.whatsapp_client.send_message(from_number, ai_response)
            
            return {"status": "success", "message": "Messages processed"}
        except Exception as e:
            print(f"Error processing messages: {e}")
            return {"status": "error", "message": str(e)}
