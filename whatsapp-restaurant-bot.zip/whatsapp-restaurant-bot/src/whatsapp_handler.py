import requests
from src.config import WHAPI_API_URL, WHAPI_API_TOKEN

class WhatsAppHandler:
    def __init__(self, ai_handler):
        self.api_url = WHAPI_API_URL
        self.api_token = WHAPI_API_TOKEN
        self.ai_handler = ai_handler
        
    def handle_message(self, message_data):
        """
        Handle incoming WhatsApp message
        
        Args:
            message_data: Message data from webhook
            
        Returns:
            Response status
        """
        try:
            # Extract message information
            if 'messages' not in message_data:
                return {"status": "error", "message": "No messages found"}
            
            for message in message_data['messages']:
                # Process only text messages
                if message.get('type') != 'text':
                    continue
                
                # Extract message details
                message_id = message.get('id')
                from_number = message.get('from')
                message_text = message.get('body', {}).get('text', '')
                
                # Generate AI response
                ai_response = self.ai_handler.generate_response(message_text)
                
                # Send response
                self.send_message(from_number, ai_response)
                
            return {"status": "success", "message": "Message processed"}
        except Exception as e:
            print(f"Error handling message: {e}")
            return {"status": "error", "message": str(e)}
    
    def send_message(self, to_number, message_text):
        """
        Send WhatsApp message
        
        Args:
            to_number: Recipient phone number
            message_text: Message text
            
        Returns:
            Response from API
        """
        try:
            headers = {
                "Authorization": f"Bearer {self.api_token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "to": to_number,
                "type": "text",
                "text": {
                    "body": message_text
                }
            }
            
            response = requests.post(
                f"{self.api_url}/messages",
                headers=headers,
                json=payload
            )
            
            if response.status_code != 200:
                print(f"Error sending message: {response.text}")
                
            return response.json()
        except Exception as e:
            print(f"Error sending message: {e}")
            raise
