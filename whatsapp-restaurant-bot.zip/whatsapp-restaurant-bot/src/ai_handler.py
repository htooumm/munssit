import google.generativeai as genai
from src.config import GEMINI_API_KEY
from src.vector_store import query_pinecone, generate_embedding

# Initialize Gemini
genai.configure(api_key=GEMINI_API_KEY)

class GeminiAI:
    def __init__(self, pinecone_index):
        self.pinecone_index = pinecone_index
        self.model = genai.GenerativeModel('gemini-flash-2.0')
        
    def generate_response(self, query, context=None):
        """
        Generate a response using Gemini AI
        
        Args:
            query: User query
            context: Additional context for the model
            
        Returns:
            Generated response
        """
        try:
            # If no context is provided, use RAG to retrieve relevant information
            if not context:
                context = self.retrieve_context(query)
            
            # Create prompt with context
            prompt = self._create_prompt(query, context)
            
            # Generate response
            response = self.model.generate_content(prompt)
            
            return response.text
        except Exception as e:
            print(f"Error generating response: {e}")
            return "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى."
    
    def retrieve_context(self, query, top_k=3):
        """
        Retrieve relevant context from Pinecone
        
        Args:
            query: User query
            top_k: Number of results to retrieve
            
        Returns:
            Context string
        """
        try:
            # Generate embedding for query
            query_embedding = generate_embedding(query)
            
            # Query Pinecone
            results = query_pinecone(self.pinecone_index, query_embedding, top_k=top_k)
            
            # Extract context from results
            context = ""
            for match in results.matches:
                context += match.metadata.get("text", "") + "\n\n"
            
            return context
        except Exception as e:
            print(f"Error retrieving context: {e}")
            return ""
    
    def _create_prompt(self, query, context):
        """
        Create a prompt for Gemini AI
        
        Args:
            query: User query
            context: Context for the model
            
        Returns:
            Formatted prompt
        """
        prompt = f"""أنت مساعد ذكي لمطعم. مهمتك هي الإجابة على استفسارات العملاء حول المنيو والطلبات والمعلومات العامة عن المطعم.

معلومات المنيو:
{context}

استخدم المعلومات أعلاه للإجابة على سؤال العميل. إذا لم تكن المعلومات متوفرة في السياق، أجب بأدب أنك لا تملك هذه المعلومات وأنك ستقوم بتوجيه العميل إلى موظف المطعم.

سؤال العميل: {query}

إجابتك:"""
        
        return prompt
