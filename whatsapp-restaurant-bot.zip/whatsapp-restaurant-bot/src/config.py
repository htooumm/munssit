import os
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

# Load configuration
def load_config():
    with open(os.path.join(os.path.dirname(__file__), '..', 'config', 'config.json'), 'r') as f:
        return json.load(f)

config = load_config()

# API Keys
PINECONE_API_KEY = os.getenv('PINECONE_API_KEY')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
WHAPI_API_TOKEN = os.getenv('WHAPI_API_TOKEN')
WHAPI_API_URL = os.getenv('WHAPI_API_URL')
RAILWAY_API_KEY = os.getenv('RAILWAY_API_KEY')

# Pinecone Configuration
PINECONE_INDEX_NAME = config['pinecone']['index_name']
PINECONE_DIMENSION = config['pinecone']['dimension']
PINECONE_METRIC = config['pinecone']['metric']

# Gemini Configuration
GEMINI_MODEL = config['gemini']['model']

# WhatsApp Configuration
WEBHOOK_PATH = config['whatsapp']['webhook_path']
VERIFY_TOKEN = config['whatsapp']['verify_token']

# App Configuration
APP_PORT = config['app']['port']
APP_HOST = config['app']['host']
