import os
import json
from src.vector_store import init_pinecone, generate_embedding, upsert_to_pinecone
from src.config import PINECONE_INDEX_NAME

def enhance_menu_data():
    """
    Enhance the menu data with additional descriptions to improve RAG performance
    """
    # Load structured menu data
    with open('/home/ubuntu/whatsapp-restaurant-bot/data/menu_structured.json', 'r', encoding='utf-8') as f:
        menu_data = json.load(f)
    
    # Add more detailed descriptions to menu items
    # This would normally be done with actual descriptions, but we'll add generic ones
    # since the OCR extraction was limited
    
    # Add more menu items based on the OCR text we saw
    categories = {
        "فطور": [
            {"name": "صحن فطور سما الشام مشكل", "price": 35.0, "description": "فطور متكامل يحتوي على تشكيلة من الأطباق المميزة"},
            {"name": "صحن فول بالطحينية", "price": 17.0, "description": "فول مدمس مع طحينة طازجة"},
            {"name": "صحن فول بالزيت", "price": 15.0, "description": "فول مدمس مع زيت زيتون"},
            {"name": "صحن بيض بالجبن", "price": 18.0, "description": "بيض مقلي مع جبنة"},
            {"name": "صحن شكشوكة", "price": 20.0, "description": "بيض مطبوخ مع الطماطم والفلفل والبصل"},
            {"name": "صحن بيض عيون", "price": 15.0, "description": "بيض مقلي على الطريقة التقليدية"},
            {"name": "صحن بيض مسلوق", "price": 12.0, "description": "بيض مسلوق طازج"}
        ],
        "شاورما": [
            {"name": "شاورما على الفحم عائلي", "price": 50.0, "description": "شاورما مشوية على الفحم، حجم عائلي"},
            {"name": "شاورما جامبو", "price": 32.0, "description": "شاورما بحجم كبير مع صلصة خاصة"},
            {"name": "شاورما لوزينا صغير", "price": 17.0, "description": "شاورما لوزينا بحجم صغير"},
            {"name": "شاورما لوزينا عائلي", "price": 45.0, "description": "شاورما لوزينا بحجم عائلي"}
        ],
        "سلطات": [
            {"name": "تبولة", "price": 15.0, "description": "سلطة تبولة طازجة مع البقدونس والبرغل"},
            {"name": "فتوش", "price": 15.0, "description": "سلطة فتوش مع الخبز المحمص والخضروات الطازجة"}
        ],
        "مقبلات": [
            {"name": "جبن سائل", "price": 18.0, "description": "جبن سائل مع الخبز"},
            {"name": "جبن عكاوي", "price": 20.0, "description": "جبن عكاوي طازج"},
            {"name": "سبانخ", "price": 15.0, "description": "فطيرة سبانخ طازجة"}
        ],
        "عربي": [
            {"name": "عربي لوزينا", "price": 25.0, "description": "ساندويش عربي لوزينا"},
            {"name": "عربي لوزينا دبل", "price": 35.0, "description": "ساندويش عربي لوزينا مضاعف"}
        ]
    }
    
    # Replace the limited menu data with enhanced data
    menu_data["menu"]["categories"] = []
    
    for category_name, items in categories.items():
        category = {
            "name": category_name,
            "items": []
        }
        
        for item in items:
            item_data = {
                "name": item["name"],
                "price": item["price"],
                "description": item["description"],
                "metadata": {
                    "category": category_name
                }
            }
            category["items"].append(item_data)
        
        menu_data["menu"]["categories"].append(category)
    
    # Save enhanced menu data
    with open('/home/ubuntu/whatsapp-restaurant-bot/data/menu_enhanced.json', 'w', encoding='utf-8') as f:
        json.dump(menu_data, f, ensure_ascii=False, indent=2)
    
    print("Enhanced menu data saved to /home/ubuntu/whatsapp-restaurant-bot/data/menu_enhanced.json")
    return menu_data

def create_menu_vectors(menu_data):
    """
    Create vector embeddings for menu items and categories
    
    Args:
        menu_data: Structured menu data
        
    Returns:
        List of vectors ready for Pinecone
    """
    vectors = []
    
    # Process each category
    for category_idx, category in enumerate(menu_data["menu"]["categories"]):
        category_name = category["name"]
        
        # Create embedding for category
        category_text = f"فئة: {category_name}"
        category_embedding = generate_embedding(category_text)
        
        category_vector = {
            "id": f"category_{category_idx}",
            "values": category_embedding,
            "metadata": {
                "type": "category",
                "name": category_name,
                "text": category_text
            }
        }
        vectors.append(category_vector)
        
        # Process each item in the category
        for item_idx, item in enumerate(category["items"]):
            item_name = item["name"]
            item_price = item["price"]
            item_description = item["description"]
            
            # Create embedding for item
            item_text = f"اسم: {item_name}. السعر: {item_price} ريال. الوصف: {item_description}. الفئة: {category_name}."
            item_embedding = generate_embedding(item_text)
            
            item_vector = {
                "id": f"item_{category_idx}_{item_idx}",
                "values": item_embedding,
                "metadata": {
                    "type": "item",
                    "name": item_name,
                    "price": item_price,
                    "description": item_description,
                    "category": category_name,
                    "text": item_text
                }
            }
            vectors.append(item_vector)
    
    return vectors

def implement_pinecone_vectors():
    """
    Implement Pinecone vector database for menu items
    """
    try:
        # Enhance menu data
        menu_data = enhance_menu_data()
        
        # Initialize Pinecone
        pinecone_index = init_pinecone()
        
        # Create vectors for menu items
        vectors = create_menu_vectors(menu_data)
        
        # Upsert vectors to Pinecone
        upsert_to_pinecone(pinecone_index, vectors)
        
        print(f"Successfully implemented Pinecone vector database with {len(vectors)} vectors")
        return True
    except Exception as e:
        print(f"Error implementing Pinecone vector database: {e}")
        return False

if __name__ == "__main__":
    implement_pinecone_vectors()
