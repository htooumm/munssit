import os
import sys
import json
import google.generativeai as genai
from langchain_google_genai import GoogleGenerativeAIEmbeddings

# Add the project root to the Python path
sys.path.append('/home/ubuntu/whatsapp-restaurant-bot')

from src.config import GEMINI_API_KEY, PINECONE_INDEX_NAME
from src.vector_store import query_pinecone, generate_embedding

class GeminiRAG:
    """
    Retrieval Augmented Generation (RAG) implementation using Gemini AI
    """
    def __init__(self, pinecone_index):
        """
        Initialize the RAG system
        
        Args:
            pinecone_index: Initialized Pinecone index
        """
        # Initialize Gemini
        genai.configure(api_key=GEMINI_API_KEY)
        
        # Initialize model - using gemini-1.5-pro instead of gemini-flash-2.0
        self.model = genai.GenerativeModel('gemini-1.5-pro')
        
        # Store Pinecone index
        self.pinecone_index = pinecone_index
        
        # Initialize embeddings
        self.embeddings = GoogleGenerativeAIEmbeddings(
            model="models/embedding-001", 
            google_api_key=GEMINI_API_KEY
        )
    
    def retrieve_relevant_context(self, query, top_k=5):
        """
        Retrieve relevant context from Pinecone based on query
        
        Args:
            query: User query
            top_k: Number of results to retrieve
            
        Returns:
            Retrieved context as string
        """
        try:
            # Generate embedding for query
            query_embedding = self.embeddings.embed_query(query)
            
            # Query Pinecone
            results = self.pinecone_index.query(
                vector=query_embedding,
                top_k=top_k,
                include_metadata=True
            )
            
            # Extract context from results
            context_items = []
            
            for match in results.matches:
                metadata = match.metadata
                
                if metadata.get("type") == "item":
                    item_text = (
                        f"اسم: {metadata.get('name')}\n"
                        f"السعر: {metadata.get('price')} ريال\n"
                        f"الوصف: {metadata.get('description')}\n"
                        f"الفئة: {metadata.get('category')}\n"
                    )
                    context_items.append(item_text)
                elif metadata.get("type") == "category":
                    category_text = f"فئة: {metadata.get('name')}\n"
                    context_items.append(category_text)
            
            # Join context items
            context = "\n".join(context_items)
            
            return context
        except Exception as e:
            print(f"Error retrieving context: {e}")
            return ""
    
    def generate_response(self, query):
        """
        Generate response using RAG
        
        Args:
            query: User query
            
        Returns:
            Generated response
        """
        try:
            # Retrieve relevant context
            context = self.retrieve_relevant_context(query)
            
            # If no context found, use a generic response
            if not context:
                context = "معلومات عن المطعم: مطعم سما الشام يقدم مجموعة متنوعة من الأطباق الشهية."
            
            # Create prompt with context
            prompt = self._create_prompt(query, context)
            
            # Generate response
            response = self.model.generate_content(prompt)
            
            return response.text
        except Exception as e:
            print(f"Error generating response: {e}")
            return "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى."
    
    def _create_prompt(self, query, context):
        """
        Create a prompt for Gemini AI
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            Formatted prompt
        """
        prompt = f"""أنت مساعد ذكي لمطعم سما الشام. مهمتك هي الإجابة على استفسارات العملاء حول المنيو والطلبات والمعلومات العامة عن المطعم.

معلومات المنيو:
{context}

قواعد الرد:
1. كن مهذباً ومحترفاً في ردودك.
2. إذا سأل العميل عن طبق موجود في المعلومات أعلاه، قدم معلومات دقيقة عن السعر والوصف.
3. إذا سأل العميل عن طبق غير موجود في المعلومات، اعتذر بلطف واقترح أطباق مشابهة من المنيو.
4. إذا كان السؤال عن ساعات العمل أو الموقع أو معلومات عامة غير متوفرة، أجب بأنك ستقوم بتوجيه العميل إلى موظف المطعم.
5. قدم اقتراحات للعملاء بناءً على استفساراتهم.

سؤال العميل: {query}

إجابتك:"""
        
        return prompt
